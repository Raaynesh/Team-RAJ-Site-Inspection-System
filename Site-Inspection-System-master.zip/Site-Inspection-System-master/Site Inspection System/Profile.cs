﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Site_Inspection_System
{
    public partial class Profile : Form
    {
        public Profile()
        {
            InitializeComponent();
            private string username;
            private string name;
            private string email;
            private string position;
            private double phonenumber;
        


    }
    }
}
